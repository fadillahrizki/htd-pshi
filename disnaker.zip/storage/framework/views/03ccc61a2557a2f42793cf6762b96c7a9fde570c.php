<div class="row">
    <div class="col-12">
        <div class="row mb-3">
            <label class="col-md-3 col-form-label" for="bpjs_kesehatan[jumlah_tenaga_kerja_laki_laki]">Jumlah Tenaga Kerja Laki-laki</label>
            <div class="col-md-9">
                <input type="number" id="bpjs_kesehatan[jumlah_tenaga_kerja_laki_laki]" value="<?php echo e(session('data_input') ? session('data_input')['bpjs_kesehatan']['jumlah_tenaga_kerja_laki_laki'] : (isset($bpjsKesehatan) ? $bpjsKesehatan->jumlah_tenaga_kerja_laki_laki : 0)); ?>" name="bpjs_kesehatan[jumlah_tenaga_kerja_laki_laki]" class="form-control <?php $__errorArgs = ['bpjs_kesehatan.jumlah_tenaga_kerja_laki_laki'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-md-3 col-form-label" for="bpjs_kesehatan[jumlah_tenaga_kerja_perempuan]">Jumlah Tenaga Kerja Perempuan</label>
            <div class="col-md-9">
                <input type="number" id="bpjs_kesehatan[jumlah_tenaga_kerja_perempuan]" value="<?php echo e(session('data_input') ? session('data_input')['bpjs_kesehatan']['jumlah_tenaga_kerja_perempuan'] : (isset($bpjsKesehatan) ? $bpjsKesehatan->jumlah_tenaga_kerja_perempuan : 0)); ?>" name="bpjs_kesehatan[jumlah_tenaga_kerja_perempuan]" class="form-control <?php $__errorArgs = ['bpjs_kesehatan.jumlah_tenaga_kerja_perempuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-md-3 col-form-label" for="bpjs_ketenagakerjaan[no_bpjs_ketenagakerjaan_perusahaan]">No BPJS Ketenagakerjaan Perusahaan</label>
            <div class="col-md-9">
                <input type="text" id="bpjs_ketenagakerjaan[no_bpjs_ketenagakerjaan_perusahaan]" value="<?php echo e(session('data_input') ? session('data_input')['bpjs_ketenagakerjaan']['no_bpjs_ketenagakerjaan_perusahaan'] : (isset($bpjsKetenagakerjaan) ? $bpjsKetenagakerjaan->no_bpjs_ketenagakerjaan_perusahaan : '')); ?>" name="bpjs_ketenagakerjaan[no_bpjs_ketenagakerjaan_perusahaan]" class="form-control <?php $__errorArgs = ['bpjs_ketenagakerjaan.no_bpjs_ketenagakerjaan_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>
        </div>
        <div class="row mb-3">

            <hr>

            <h5>Program Jaminan Sosial</h5>

            <?php $__currentLoopData = \App\Models\RefJaminanSosial::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jamsos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12">
                <div class="row mb-3">
                    <label class="col-md-3 col-form-label"><?php echo e($jamsos->nama); ?></label>
                    <div class="col-md-9">
                        <div class="row">
                            <div class="col-6">
                                <label class="mb-2" for="bpjs_ketenagakerjaan[program_jaminan_sosial][<?php echo e($jamsos->id); ?>][lk]">Jumlah Tenaga Kerja Laki-laki</label>
                                <input type="number" id="bpjs_ketenagakerjaan[program_jaminan_sosial][<?php echo e($jamsos->id); ?>][lk]" value="<?php echo e(session('data_input') ? session('data_input')['bpjs_ketenagakerjaan']['program_jaminan_sosial'][$jamsos->id]['lk'] : (isset($jaminanSosial) ? $jaminanSosial[$jamsos->id]['lk'] : '')); ?>" name="bpjs_ketenagakerjaan[program_jaminan_sosial][<?php echo e($jamsos->id); ?>][lk]" class="form-control <?php $__errorArgs = ['bpjs_ketenagakerjaan.program_jaminan_sosial.'.$jamsos->id.'.lk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            </div>
                            <div class="col-6">
                                <label class="mb-2" for="bpjs_ketenagakerjaan[program_jaminan_sosial][<?php echo e($jamsos->id); ?>][pr]">Jumlah Tenaga Kerja Perempuan</label>
                                <input type="number" id="bpjs_ketenagakerjaan[program_jaminan_sosial][<?php echo e($jamsos->id); ?>][pr]" value="<?php echo e(session('data_input') ? session('data_input')['bpjs_ketenagakerjaan']['program_jaminan_sosial'][$jamsos->id]['pr'] :  (isset($jaminanSosial) ? $jaminanSosial[$jamsos->id]['pr'] : '')); ?>" name="bpjs_ketenagakerjaan[program_jaminan_sosial][<?php echo e($jamsos->id); ?>][pr]" class="form-control <?php $__errorArgs = ['bpjs_ketenagakerjaan.program_jaminan_sosial.'.$jamsos->id.'.pr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div> <!-- end col -->
</div> <!-- end row --><?php /**PATH C:\laragon\www\pshi\resources\views/perusahaan/partials/jamsos.blade.php ENDPATH**/ ?>