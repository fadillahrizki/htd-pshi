

<?php $__env->startSection('title', 'Data Perusahaan'); ?>

<?php $__env->startSection('content'); ?>

<!-- Start Content-->
<div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dinas Ketenagakerjaan Kota Tanjung Balai</a></li>
                        <li class="breadcrumb-item active">Data Perusahaan</li>
                    </ol>
                </div>
                <h4 class="page-title">Data Perusahaan</h4>
            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(route('office.create')); ?>" class="btn btn-primary">
                        <i class="mdi mdi-plus"></i>
                        <span class="ml-2">Tambah Data</span>
                    </a>
                </div>
                <div class="card-body">
                    <?php if(session()->get('message')): ?>
                        <div class="alert alert-info">
                            <?php echo e(session()->get('message')); ?>    
                        </div>
                    <?php endif; ?>

                    <table id="basic-datatable" class="table table-striped dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Nama Perusahaan</th>
                                <th>No Telepon</th>
                                <th>Email Perusahaan</th>
                                <th>Jenis Usaha</th>
                                <th data-orderable="false">Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($dt->user->name); ?> (<?php echo e($dt->user->email); ?>)</td>
                                <td><?php echo e($dt->nama_perusahaan); ?></td>
                                <td><?php echo e($dt->no_telepon); ?></td>
                                <td><?php echo e($dt->email); ?></td>
                                <td><?php echo e($dt->jenis_usaha); ?></td>
                                <td>
                                    <a href="<?php echo e(route('office.view', $dt)); ?>" class="btn btn-info" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Lihat Detail"> 
                                        <i class="mdi mdi-eye"></i>
                                    </a>
                                    
                                    <a href="<?php echo e(route('office.edit', $dt->id)); ?>" class="btn btn-warning" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Edit"> 
                                        <i class="mdi mdi-pencil"></i>
                                    </a>

                                    
                                    <a href="#" onclick="action(event, <?php echo e($dt->id); ?>, 'delete')" class="btn btn-danger" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Hapus">
                                        <i class="mdi mdi-delete"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div> <!-- end row-->

</div>
<!-- container -->

<form id="form" method="POST" style="display: none;">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="id">
    <input type="hidden" name="type">
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
    function action(event, id, type) {
        event.preventDefault()

        var form = document.getElementById('form')
        form['id'].value = id
        form['type'].value = type
        form.submit()
        
    }

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pshi\resources\views/perusahaan/index.blade.php ENDPATH**/ ?>