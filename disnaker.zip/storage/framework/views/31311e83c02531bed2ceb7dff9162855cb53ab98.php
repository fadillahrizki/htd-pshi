<div class="row mb-3">
    <hr>

    <label class="col-md-3 col-form-label">Pelaksanaan Cuti</label>
    <div class="col-md-9 m-auto">
        <?php $__currentLoopData = \App\Models\RefCuti::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-check form-check-inline">
            <input type="checkbox" id="pelaksanaan_cuti_<?php echo e($cuti->id); ?>" name="pelaksanaan_cuti[<?php echo e($cuti->id); ?>]" class="form-check-input" <?php if((session('data_input') && isset(session('data_input')['pelaksanaan_cuti']) && session('data_input')['pelaksanaan_cuti'][$cuti->id] == 'on') || (isset($selectedCuti) && in_array($cuti->id, $selectedCuti))): ?> checked <?php endif; ?>>
            <label class="form-check-label" for="pelaksanaan_cuti_<?php echo e($cuti->id); ?>"><?php echo e($cuti->nama); ?></label>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH C:\laragon\www\pshi\resources\views/perusahaan/partials/cuti.blade.php ENDPATH**/ ?>