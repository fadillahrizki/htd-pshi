<div class="row">
    <div class="col-12">
        <?php $__currentLoopData = \App\Models\RefKategoriFasilitas::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row mb-3">
            <label class="col-md-3 col-form-label"><?php echo e($kategori->nama); ?></label>
            <div class="col-md-9">
                <?php $__currentLoopData = $kategori->fasilitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $fasilitas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check">
                    <input type="checkbox" 
                            id="kategori_<?php echo e($kategori->id); ?>_<?php echo e($index); ?>" 
                            name="kategori[<?php echo e($kategori->id); ?>][<?php echo e($fasilitas->id); ?>]" class="form-check-input"
                            <?php if(request()->routeIs('office.edit')): ?>
                            <?php if(in_array($fasilitas->id, $selectedFasilitas)): ?>
                            checked=""
                            <?php endif; ?>
                            <?php else: ?>
                            <?php if(session('data_input') && isset(session('data_input')['kategori']) && in_array($fasilitas->id, array_keys(session('data_input')['kategori'][$kategori->id]))): ?>
                            checked=""
                            <?php endif; ?>
                            <?php endif; ?>
                            >
                    <label class="form-check-label" for="kategori_<?php echo e($kategori->id); ?>_<?php echo e($index); ?>"><?php echo e($fasilitas->nama); ?></label>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div> <!-- end col -->
</div> <!-- end row --><?php /**PATH C:\laragon\www\pshi\resources\views/perusahaan/partials/fasilitas.blade.php ENDPATH**/ ?>