<div class="row mb-3">
    <label class="col-md-3 col-form-label">Perangkat Hubungan Kerja</label>
    <div class="col-md-9 m-auto">
        <?php echo e($dataUmum->perangkat_hubungan_industri->perangkat_hubungan_kerja); ?>

    </div>
</div>
<div class="row mb-3">
    <label class="col-md-3 col-form-label">Perjanjian Kerja</label>
    <div class="col-md-9 m-auto">
        <?php echo e($dataUmum->perangkat_hubungan_industri->perjanjian_kerja); ?>

    </div>
</div>
<div class="row mb-3">
    <label class="col-md-3 col-form-label">LKS Bipartite</label>
    <div class="col-md-9 m-auto">
        <?php echo e($dataUmum->perangkat_hubungan_industri->lks_bipartite); ?>

    </div>
</div>
<div class="row mb-3">
    <label class="col-md-3 col-form-label">Serikat Pekerja / Buruh</label>
    <div class="col-md-9 m-auto">
        <?php echo e($dataUmum->perangkat_hubungan_industri->serikat_pekerja_buruh); ?>

    </div>
</div>
<div class="row mb-3">
    <label class="col-md-3 col-form-label" for="perangkat_hubungan_industri[nama_serikat_pekerja_buruh]">Nama Serikat Pekerja/Buruh</label>
    <div class="col-md-9">
        <?php echo e($dataUmum->perangkat_hubungan_industri->nama_serikat_pekerja_buruh); ?>

    </div>
</div>
<div class="row mb-3">

    <hr>

    <h5>Kondisi Tenaga Kerja</h5>

    <?php $__currentLoopData = $dataUmum->kondisiTk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lulusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-12">
        <div class="row mb-3">
            <label class="col-md-3 col-form-label"><?php echo e($lulusan->lulusan->nama); ?></label>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-6">
                        <label class="mb-2" for="perangkat_hubungan_industri[kondisi_tenaga_kerja][<?php echo e($lulusan->id); ?>][lk]">Laki-laki</label><br>
                        <?php echo e($lulusan->jumlah_lk); ?>

                    </div>
                    <div class="col-6">
                        <label class="mb-2" for="perangkat_hubungan_industri[kondisi_tenaga_kerja][<?php echo e($lulusan->id); ?>][pr]">Perempuan</label><br>
                        <?php echo e($lulusan->jumlah_pr); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\laragon\www\pshi\resources\views/perusahaan/partials/show_hubungan_industri.blade.php ENDPATH**/ ?>