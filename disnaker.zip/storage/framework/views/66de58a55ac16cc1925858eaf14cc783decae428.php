

<?php $__env->startSection('title', 'Data Pengaduan'); ?>

<?php $__env->startSection('content'); ?>
<!-- Start Content-->
<div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dinas Ketenagakerjaan Kota Tanjung Balai</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('tickets.index')); ?>">Data Pengaduan</a></li>
                        <li class="breadcrumb-item active"><?php echo e(request()->routeIs('tickets.create') ? 'Tambah' : 'Edit'); ?></li>
                    </ol>
                </div>
                <h4 class="page-title">Data Pengaduan</h4>
            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                
                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            Gagal mengirimkan data!
                        </div>
                    <?php endif; ?>

                    <?php if(session()->get('status') == 'success'): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session()->get('message')); ?>

                        </div>
                    <?php elseif(session()->get('status') == 'failed'): ?>

                        <div class="alert alert-danger" role="alert">
                            <?php echo e(session()->get('message')); ?>

                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(request()->routeIs('tickets.create') ? route('tickets.store') : route('tickets.update', $ticket->id)); ?>" method="post" id="form-main">
                        <?php echo csrf_field(); ?>

                        <?php if(request()->routeIs('tickets.edit')): ?>
                        <?php echo method_field('PUT'); ?>
                        <?php endif; ?>

                        <div class="form-group mb-2">
                            <label for="" class="mb-1">Subject</label>
                            <input type="text" name="subject" id="" class="form-control" value="<?php echo e(old('name', $ticket?->subject)); ?>" placeholder="Subject">
                        </div>
                        
                        <div class="form-group mb-2">
                            <label for="" class="mb-1">Deskripsi</label>
                            <textarea name="description" id="" cols="30" rows="6" class="form-control"><?php echo e(old('name', $ticket?->description)); ?></textarea>
                        </div>
                        
                        <div class="form-group mb-2">
                            <label for="" class="mb-1">Prioritas</label>
                            <select name="priority" id="" class="form-control">
                                <?php $__currentLoopData = ['LOW','MEDIUN','HIGH','URGENT']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option><?php echo e($priority); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        

                        <button class="btn btn-primary">Submit</button>
                        <a href="<?php echo e(route('tickets.index')); ?>" class="btn btn-warning">Kembali</a>
                    </form>

                </div> <!-- end card-body -->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>

</div>
<!-- container -->

<form id="form" method="POST" style="display: none;">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="id">
    <input type="hidden" name="type">
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
    function action(event, id, type) {
        event.preventDefault()

        var form = document.getElementById('form')
        form['id'].value = id
        form['type'].value = type
        form.submit()
        
    }

    function submitForm(type) {
        var form = document.getElementById('form-main')
        form['type'].value = type
        form.submit()
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pshi\resources\views/tickets/form.blade.php ENDPATH**/ ?>