<?php

    $kasus_perselisihan = [
        'pemutusan_hubungan_kerja' => old('kasus_perselisihan')['pemutusan_hubungan_kerja'] ?? ($kasusPerselisihan['pemutusan_hubungan_kerja'] ?? (session('data_input')['kasus_perselisihan']['pemutusan_hubungan_kerja'] ?? '' )),
        'serikat_pekerja_buruh' => old('kasus_perselisihan')['serikat_pekerja_buruh'] ?? ($kasusPerselisihan['serikat_pekerja_buruh'] ?? (session('data_input')['kasus_perselisihan']['serikat_pekerja_buruh'] ?? '' )),
        'mogok_kerja' => old('kasus_perselisihan')['mogok_kerja'] ?? ($kasusPerselisihan['mogok_kerja'] ?? (session('data_input')['kasus_perselisihan']['mogok_kerja'] ?? '' )),
        'lock_out' => old('kasus_perselisihan')['lock_out'] ?? ($kasusPerselisihan['lock_out'] ?? (session('data_input')['kasus_perselisihan']['lock_out'] ?? '' )),
    ];

?>

<div class="row mb-3">
    <hr>
    <h5>Kasus / Perselisihan</h5>

    <div class="row mb-3">
        <label class="col-md-3 col-form-label" for="kasus_perselisihan[pemutusan_hubungan_kerja]">Pemutusan Hubungan Kerja</label>
        <div class="col-md-9">
            <input <?php if(isset($kasusPerselisihan)): ?> disabled <?php endif; ?> type="number" id="kasus_perselisihan[pemutusan_hubungan_kerja]" value="<?php echo e($kasus_perselisihan['pemutusan_hubungan_kerja']); ?>" name="kasus_perselisihan[pemutusan_hubungan_kerja]" class="form-control <?php $__errorArgs = ['kasus_perselisihan.pemutusan_hubungan_kerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        </div>
    </div>
    <div class="row mb-3">
        <label class="col-md-3 col-form-label" for="kasus_perselisihan[serikat_pekerja_buruh]">Serikat Pekerja / Buruh</label>
        <div class="col-md-9">
            <input <?php if(isset($kasusPerselisihan)): ?> disabled <?php endif; ?> type="number" id="kasus_perselisihan[serikat_pekerja_buruh]" value="<?php echo e($kasus_perselisihan['serikat_pekerja_buruh']); ?>" name="kasus_perselisihan[serikat_pekerja_buruh]" class="form-control <?php $__errorArgs = ['kasus_perselisihan.serikat_pekerja_buruh'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        </div>
    </div>
    <div class="row mb-3">
        <label class="col-md-3 col-form-label" for="kasus_perselisihan[mogok_kerja]">Mogok Kerja</label>
        <div class="col-md-9">
            <input <?php if(isset($kasusPerselisihan)): ?> disabled <?php endif; ?> type="number" id="kasus_perselisihan[mogok_kerja]" value="<?php echo e($kasus_perselisihan['mogok_kerja']); ?>" name="kasus_perselisihan[mogok_kerja]" class="form-control <?php $__errorArgs = ['kasus_perselisihan.mogok_kerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        </div>
    </div>
    <div class="row mb-3">
        <label class="col-md-3 col-form-label" for="kasus_perselisihan[lock_out]">Lock Out (Penutupan Perusahaan)</label>
        <div class="col-md-9">
            <input <?php if(isset($kasusPerselisihan)): ?> disabled <?php endif; ?> type="number" id="kasus_perselisihan[lock_out]" value="<?php echo e($kasus_perselisihan['lock_out']); ?>" name="kasus_perselisihan[lock_out]" class="form-control <?php $__errorArgs = ['kasus_perselisihan.lock_out'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\pshi\resources\views/perusahaan/partials/kasus_perselisihan.blade.php ENDPATH**/ ?>