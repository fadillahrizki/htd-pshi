<div class="row mb-3">
    <hr>

    <label class="col-md-3 col-form-label">Pelaksanaan Cuti</label>
    <div class="col-md-9 m-auto">
        <?php $__currentLoopData = $dataUmum->cuti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-check form-check-inline">
            <label class="form-check-label" for="pelaksanaan_cuti_<?php echo e($cuti->id); ?>"><?php echo e($cuti->cuti->nama); ?></label>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH C:\laragon\www\pshi\resources\views/perusahaan/partials/show_cuti.blade.php ENDPATH**/ ?>