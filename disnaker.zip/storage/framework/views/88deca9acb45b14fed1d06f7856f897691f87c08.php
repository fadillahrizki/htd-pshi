

<?php $__env->startSection('title', 'Account Verification'); ?>

<?php $__env->startSection('content'); ?>

<!-- Start Content-->
<div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Velonic</a></li>
                        <li class="breadcrumb-item active">Account Verification</li>
                    </ol>
                </div>
                <h4 class="page-title">Account Verification</h4>
            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <?php if(session()->get('message')): ?>
                        <div class="alert alert-info">
                            <?php echo e(session()->get('message')); ?>    
                        </div>
                    <?php endif; ?>

                    <table id="basic-datatable" class="table table-striped dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Status</th>
                                <th data-orderable="false">Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($account->name); ?></td>
                                <td><?php echo e($account->email); ?></td>
                                <td>
                                    <span class="badge <?php echo e(($account->status == 'Waiting' ? 'bg-info' : ($account->status == 'Verified' ? 'bg-success' : 'bg-danger'))); ?>"><?php echo e($account->status); ?></span>
                                </td>
                                <td>
                                    <?php if($account->status == 'Waiting'): ?>
                                        <a href="#" onclick="action(event, <?php echo e($account->id); ?>, 'verify')" class="btn btn-success" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-title="Verify"> 
                                            <i class="mdi mdi-file-check"></i>
                                        </a>
                                        <a href="#" onclick="action(event, <?php echo e($account->id); ?>, 'reject')" class="btn btn-danger" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Reject">
                                            <i class="mdi mdi-file-cancel"></i>
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div> <!-- end row-->

</div>
<!-- container -->

<form id="form" method="POST" style="display: none;">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="id">
    <input type="hidden" name="type">
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
    function action(event, id, type) {
        event.preventDefault()

        var form = document.getElementById('form')
        form['id'].value = id
        form['type'].value = type
        form.submit()
        
    }

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pshi\resources\views/admin/account_verification.blade.php ENDPATH**/ ?>