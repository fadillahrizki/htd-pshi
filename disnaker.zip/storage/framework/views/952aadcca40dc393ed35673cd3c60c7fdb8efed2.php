<div class="row">
    <div class="col-12">
        <?php $__currentLoopData = \App\Models\RefKategoriFasilitas::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row mb-3">
            <label class="col-md-3 col-form-label"><?php echo e($kategori->nama); ?></label>
            <div class="col-md-9">
                <?php $__currentLoopData = $dataUmum->fasilitas()->whereHas('fasilitas', function($q) use ($kategori){ $q->where('kategori_id', $kategori->id); })->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $fasilitas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($fasilitas->fasilitas->nama); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div> <!-- end col -->
</div> <!-- end row --><?php /**PATH C:\laragon\www\pshi\resources\views/perusahaan/partials/show_fasilitas.blade.php ENDPATH**/ ?>