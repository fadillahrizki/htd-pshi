<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully responsive admin theme which can be used to build CRM, CMS,ERP etc." name="description" />
    <meta content="Techzaa" name="author" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/logo-tanjung-balai.png')); ?>">

    <!-- Daterangepicker css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/daterangepicker/daterangepicker.css')); ?>">

    <!-- Vector Map css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.css')); ?>">

    <!-- Theme Config Js -->
    <script src="<?php echo e(asset('assets/js/config.js')); ?>"></script>

    <!-- App css -->
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="app-style" />

    <!-- Icons css -->
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />

     <!-- Datatables css -->
    <link href="<?php echo e(asset('assets/vendor/datatables.net-bs5/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/vendor/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css')); ?>" rel="stylesheet"
        type="text/css" />
    <link href="<?php echo e(asset('assets/vendor/datatables.net-fixedcolumns-bs5/css/fixedColumns.bootstrap5.min.css')); ?>" rel="stylesheet"
        type="text/css" />
    <link href="<?php echo e(asset('assets/vendor/datatables.net-fixedheader-bs5/css/fixedHeader.bootstrap5.min.css')); ?>" rel="stylesheet"
        type="text/css" />
    <link href="<?php echo e(asset('assets/vendor/datatables.net-buttons-bs5/css/buttons.bootstrap5.min.css')); ?>" rel="stylesheet"
        type="text/css" />
    <link href="<?php echo e(asset('assets/vendor/datatables.net-select-bs5/css/select.bootstrap5.min.css')); ?>" rel="stylesheet"
        type="text/css" />

    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>

    <!-- Begin page -->
    <div class="wrapper">

        <!-- ========== Topbar Start ========== -->
        <div class="navbar-custom">
            <div class="topbar container-fluid">
                <div class="d-flex align-items-center gap-1">

                    <!-- Topbar Brand Logo -->
                    <div class="logo-topbar">
                        <!-- Logo light -->
                        <a href="<?php echo e(url('/')); ?>" class="logo-light">
                            <img src="<?php echo e(asset('assets/images/logo-tanjung-balai.png')); ?>" width="100px" alt="logo">
                        </a>

                        <!-- Logo Dark -->
                        <a href="<?php echo e(url('/')); ?>" class="logo-dark">
                            <img src="<?php echo e(asset('assets/images/logo-tanjung-balai.png')); ?>" alt="small logo">
                        </a>
                    </div>

                    <!-- Sidebar Menu Toggle Button -->
                    <button class="button-toggle-menu">
                        <i class="ri-menu-line"></i>
                    </button>

                    <!-- Horizontal Menu Toggle Button -->
                    <button class="navbar-toggle" data-bs-toggle="collapse" data-bs-target="#topnav-menu-content">
                        <div class="lines">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </button>
                </div>

                <ul class="topbar-menu d-flex align-items-center gap-3">

                    <li class="dropdown">
                        <a class="nav-link dropdown-toggle arrow-none nav-user" data-bs-toggle="dropdown" href="#" role="button"
                            aria-haspopup="false" aria-expanded="false">
                            <span class="account-user-avatar">
                                <img src="<?php echo e(asset('assets/images/users/avatar-1.jpg')); ?>" alt="user-image" width="32" class="rounded-circle">
                            </span>
                            <span class="d-lg-block d-none">
                                <h5 class="my-0 fw-normal"><?php echo e(auth()->user()->name); ?> <i
                                        class="ri-arrow-down-s-line d-none d-sm-inline-block align-middle"></i></h5>
                            </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end dropdown-menu-animated profile-dropdown">
                            <!-- item-->
                            <a href="<?php echo e(route('logout')); ?>" class="dropdown-item">
                                <i class="ri-logout-box-line fs-18 align-middle me-1"></i>
                                <span>Logout</span>
                            </a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <!-- ========== Topbar End ========== -->
        

        <!-- ========== Left Sidebar Start ========== -->
        <div class="leftside-menu">

            <!-- Brand Logo Light -->
            <a href="<?php echo e(url('/')); ?>" class="logo logo-light mt-2">
                <img src="<?php echo e(asset('assets/images/logo-tanjung-balai.png')); ?>" alt="logo" width="100px">
            </a>

            <!-- Brand Logo Dark -->
            <a href="<?php echo e(url('/')); ?>" class="logo logo-dark">
                <span class="logo-lg">
                    <img src="<?php echo e(asset('assets/images/logo-dark.png')); ?>" alt="dark logo">
                </span>
                <span class="logo-sm">
                    <img src="<?php echo e(asset('assets/images/logo-tanjung-balai.png')); ?>" alt="small logo">
                </span>
            </a>

            <!-- Sidebar -left -->
            <div class="h-100" id="leftside-menu-container" data-simplebar>
                <!--- Sidemenu -->
                <ul class="side-nav">

                    <li class="side-nav-title">Main</li>

                    <li class="side-nav-item">
                        <a href="<?php echo e(route('home')); ?>" class="side-nav-link">
                            <i class="ri-dashboard-3-line"></i>
                            <!-- <span class="badge bg-success float-end">9+</span> -->
                            <span> Dashboard </span>
                        </a>
                    </li>

                    <?php if(auth()->user()->role == "Admin"): ?>
                    
                    <li class="side-nav-item">
                        <a href="<?php echo e(route('admin.kategori-fasilitas.index')); ?>" class="side-nav-link">
                            <i class="mdi mdi-animation"></i>
                            <!-- <span class="badge bg-success float-end">9+</span> -->
                            <span> Kategori Fasilitas </span>
                        </a>
                    </li>
                    
                    <li class="side-nav-item">
                        <a href="<?php echo e(route('admin.fasilitas.index')); ?>" class="side-nav-link">
                            <i class="mdi mdi-archive"></i>
                            <!-- <span class="badge bg-success float-end">9+</span> -->
                            <span> Fasilitas </span>
                        </a>
                    </li>
                    
                    <li class="side-nav-item">
                        <a href="<?php echo e(route('admin.jaminan-sosial.index')); ?>" class="side-nav-link">
                            <i class="mdi mdi-hand-heart-outline"></i>
                            <!-- <span class="badge bg-success float-end">9+</span> -->
                            <span> Jaminan Sosial </span>
                        </a>
                    </li>

                    <li class="side-nav-item">
                        <a href="<?php echo e(route('admin.lulusan.index')); ?>" class="side-nav-link">
                            <i class="mdi mdi-school"></i>
                            <!-- <span class="badge bg-success float-end">9+</span> -->
                            <span> Lulusan </span>
                        </a>
                    </li>
                    
                    <li class="side-nav-item">
                        <a href="<?php echo e(route('admin.cuti.index')); ?>" class="side-nav-link">
                            <i class="mdi mdi-tent"></i>
                            <!-- <span class="badge bg-success float-end">9+</span> -->
                            <span> Cuti </span>
                        </a>
                    </li>
                    
                    <li class="side-nav-item">
                        <a href="<?php echo e(route('admin.accounts.index')); ?>" class="side-nav-link">
                            <i class="mdi mdi-account"></i>
                            <!-- <span class="badge bg-success float-end">9+</span> -->
                            <span> Akun Perusahaan </span>
                        </a>
                    </li>

                    <?php endif; ?>

                    <li class="side-nav-item">
                        <a href="<?php echo e(route('office.index')); ?>" class="side-nav-link">
                            <i class="mdi mdi-office-building"></i>
                            <!-- <span class="badge bg-success float-end">9+</span> -->
                            <span> Data Perusahaan </span>
                        </a>
                    </li>
                    
                    <li class="side-nav-item">
                        <a href="<?php echo e(route('tickets.index')); ?>" class="side-nav-link">
                            <i class="mdi mdi-ticket-outline"></i>
                            <!-- <span class="badge bg-success float-end">9+</span> -->
                            <span> Pengaduan </span>
                        </a>
                    </li>

                </ul>
                <!--- End Sidemenu -->

                <div class="clearfix"></div>
            </div>
        </div>
        <!-- ========== Left Sidebar End ========== -->

        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->

        <div class="content-page">
            <div class="content">

                <?php echo $__env->yieldContent('content'); ?>

            </div>
            <!-- content -->

            <!-- Footer Start -->
            <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12 text-center">
                            <script>document.write(new Date().getFullYear())</script> © DISNAKER TANJUNG BALAI
                        </div>
                    </div>
                </div>
            </footer>
            <!-- end Footer -->

        </div>

        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->

    </div>
    <!-- END wrapper -->

    <!-- Theme Settings -->
    <div class="offcanvas offcanvas-end" tabindex="-1" id="theme-settings-offcanvas">
        <div class="d-flex align-items-center bg-primary p-3 offcanvas-header">
            <h5 class="text-white m-0">Theme Settings</h5>
            <button type="button" class="btn-close btn-close-white ms-auto" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>

        <div class="offcanvas-body p-0">
            <div data-simplebar class="h-100">
                <div class="p-3">
                    <h5 class="mb-3 fs-16 fw-bold">Color Scheme</h5>

                    <div class="row">
                        <div class="col-4">
                            <div class="form-check form-switch card-switch mb-1">
                                <input class="form-check-input" type="checkbox" name="data-bs-theme" id="layout-color-light" value="light">
                                <label class="form-check-label" for="layout-color-light">
                                    <img src="<?php echo e(asset('assets/images/layouts/light.png')); ?>" alt="" class="img-fluid">
                                </label>
                            </div>
                            <h5 class="font-14 text-center text-muted mt-2">Light</h5>
                        </div>

                        <div class="col-4">
                            <div class="form-check form-switch card-switch mb-1">
                                <input class="form-check-input" type="checkbox" name="data-bs-theme" id="layout-color-dark" value="dark">
                                <label class="form-check-label" for="layout-color-dark">
                                    <img src="<?php echo e(asset('assets/images/layouts/dark.png')); ?>" alt="" class="img-fluid">
                                </label>
                            </div>
                            <h5 class="font-14 text-center text-muted mt-2">Dark</h5>
                        </div>
                    </div>

                    <div id="layout-width">
                        <h5 class="my-3 fs-16 fw-bold">Layout Mode</h5>

                        <div class="row">
                            <div class="col-4">
                                <div class="form-check form-switch card-switch mb-1">
                                    <input class="form-check-input" type="checkbox" name="data-layout-mode" id="layout-mode-fluid" value="fluid">
                                    <label class="form-check-label" for="layout-mode-fluid">
                                        <img src="<?php echo e(asset('assets/images/layouts/light.png')); ?>" alt="" class="img-fluid">
                                    </label>
                                </div>
                                <h5 class="font-14 text-center text-muted mt-2">Fluid</h5>
                            </div>

                            <div class="col-4">
                                <div id="layout-boxed">
                                    <div class="form-check form-switch card-switch mb-1">
                                        <input class="form-check-input" type="checkbox" name="data-layout-mode" id="layout-mode-boxed" value="boxed">
                                        <label class="form-check-label" for="layout-mode-boxed">
                                            <img src="<?php echo e(asset('assets/images/layouts/boxed.png')); ?>" alt="" class="img-fluid">
                                        </label>
                                    </div>
                                    <h5 class="font-14 text-center text-muted mt-2">Boxed</h5>
                                </div>
                            </div>
                        </div>
                    </div>

                    <h5 class="my-3 fs-16 fw-bold">Topbar Color</h5>

                    <div class="row">
                        <div class="col-4">
                            <div class="form-check form-switch card-switch mb-1">
                                <input class="form-check-input" type="checkbox" name="data-topbar-color" id="topbar-color-light" value="light">
                                <label class="form-check-label" for="topbar-color-light">
                                    <img src="<?php echo e(asset('assets/images/layouts/light.png')); ?>" alt="" class="img-fluid">
                                </label>
                            </div>
                            <h5 class="font-14 text-center text-muted mt-2">Light</h5>
                        </div>

                        <div class="col-4">
                            <div class="form-check form-switch card-switch mb-1">
                                <input class="form-check-input" type="checkbox" name="data-topbar-color" id="topbar-color-dark" value="dark">
                                <label class="form-check-label" for="topbar-color-dark">
                                    <img src="<?php echo e(asset('assets/images/layouts/topbar-dark.png')); ?>" alt="" class="img-fluid">
                                </label>
                            </div>
                            <h5 class="font-14 text-center text-muted mt-2">Dark</h5>
                        </div>
                    </div>

                    <div>
                        <h5 class="my-3 fs-16 fw-bold">Menu Color</h5>

                        <div class="row">
                            <div class="col-4">
                                <div class="form-check form-switch card-switch mb-1">
                                    <input class="form-check-input" type="checkbox" name="data-menu-color" id="leftbar-color-light" value="light">
                                    <label class="form-check-label" for="leftbar-color-light">
                                        <img src="<?php echo e(asset('assets/images/layouts/sidebar-light.png')); ?>" alt="" class="img-fluid">
                                    </label>
                                </div>
                                <h5 class="font-14 text-center text-muted mt-2">Light</h5>
                            </div>

                            <div class="col-4">
                                <div class="form-check form-switch card-switch mb-1">
                                    <input class="form-check-input" type="checkbox" name="data-menu-color" id="leftbar-color-dark" value="dark">
                                    <label class="form-check-label" for="leftbar-color-dark">
                                        <img src="<?php echo e(asset('assets/images/layouts/light.png')); ?>" alt="" class="img-fluid">
                                    </label>
                                </div>
                                <h5 class="font-14 text-center text-muted mt-2">Dark</h5>
                            </div>
                        </div>
                    </div>

                    <div id="sidebar-size">
                        <h5 class="my-3 fs-16 fw-bold">Sidebar Size</h5>

                        <div class="row">
                            <div class="col-4">
                                <div class="form-check form-switch card-switch mb-1">
                                    <input class="form-check-input" type="checkbox" name="data-sidenav-size" id="leftbar-size-default" value="default">
                                    <label class="form-check-label" for="leftbar-size-default">
                                        <img src="<?php echo e(asset('assets/images/layouts/light.png')); ?>" alt="" class="img-fluid">
                                    </label>
                                </div>
                                <h5 class="font-14 text-center text-muted mt-2">Default</h5>
                            </div>

                            <div class="col-4">
                                <div class="form-check form-switch card-switch mb-1">
                                    <input class="form-check-input" type="checkbox" name="data-sidenav-size" id="leftbar-size-compact" value="compact">
                                    <label class="form-check-label" for="leftbar-size-compact">
                                        <img src="<?php echo e(asset('assets/images/layouts/compact.png')); ?>" alt="" class="img-fluid">
                                    </label>
                                </div>
                                <h5 class="font-14 text-center text-muted mt-2">Compact</h5>
                            </div>

                            <div class="col-4">
                                <div class="form-check form-switch card-switch mb-1">
                                    <input class="form-check-input" type="checkbox" name="data-sidenav-size" id="leftbar-size-small" value="condensed">
                                    <label class="form-check-label" for="leftbar-size-small">
                                        <img src="<?php echo e(asset('assets/images/layouts/sm.png')); ?>" alt="" class="img-fluid">
                                    </label>
                                </div>
                                <h5 class="font-14 text-center text-muted mt-2">Condensed</h5>
                            </div>


                            <div class="col-4">
                                <div class="form-check form-switch card-switch mb-1">
                                    <input class="form-check-input" type="checkbox" name="data-sidenav-size" id="leftbar-size-full" value="full">
                                    <label class="form-check-label" for="leftbar-size-full">
                                        <img src="<?php echo e(asset('assets/images/layouts/full.png')); ?>" alt="" class="img-fluid">
                                    </label>
                                </div>
                                <h5 class="font-14 text-center text-muted mt-2">Full Layout</h5>
                            </div>
                        </div>
                    </div>

                    <div id="layout-position">
                        <h5 class="my-3 fs-16 fw-bold">Layout Position</h5>

                        <div class="btn-group checkbox" role="group">
                            <input type="radio" class="btn-check" name="data-layout-position" id="layout-position-fixed" value="fixed">
                            <label class="btn btn-soft-primary w-sm" for="layout-position-fixed">Fixed</label>

                            <input type="radio" class="btn-check" name="data-layout-position" id="layout-position-scrollable" value="scrollable">
                            <label class="btn btn-soft-primary w-sm ms-0" for="layout-position-scrollable">Scrollable</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="offcanvas-footer border-top p-3 text-center">
            <div class="row">
                <div class="col-6">
                    <button type="button" class="btn btn-light w-100" id="reset-layout">Reset</button>
                </div>
                <div class="col-6">
                    <a href="https://1.envato.market/Dinas Ketenagakerjaan Kota Tanjung Balai" target="_blank" role="button" class="btn btn-primary w-100">Buy Now</a>
                </div>
            </div>
        </div>
    </div>        

    <!-- Vendor js -->
    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>

    <!-- Daterangepicker js -->
    <script src="<?php echo e(asset('assets/vendor/daterangepicker/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/daterangepicker/daterangepicker.js')); ?>"></script>

    <!-- Apex Charts js -->
    <script src="<?php echo e(asset('assets/vendor/apexcharts/apexcharts.min.js')); ?>"></script>

    <!-- Vector Map js -->
    <script src="<?php echo e(asset('assets/vendor/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/admin-resources/jquery.vectormap/maps/jquery-jvectormap-world-mill-en.js')); ?>"></script>

    <!-- Dashboard App js -->
    <script src="<?php echo e(asset('assets/js/pages/dashboard.js')); ?>"></script>
    
    <!-- Datatables js -->
    <script src="<?php echo e(asset('assets/vendor/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/datatables.net-bs5/js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/datatables.net-fixedcolumns-bs5/js/fixedColumns.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/datatables.net-buttons-bs5/js/buttons.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/datatables.net-buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/datatables.net-buttons/js/buttons.flash.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/datatables.net-keytable/js/dataTables.keyTable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/datatables.net-select/js/dataTables.select.min.js')); ?>"></script>
    
    <!-- Datatable Demo Aapp js -->
    <script src="<?php echo e(asset('assets/js/pages/datatable.init.js')); ?>"></script>

    
    <!-- Bootstrap Wizard Form js -->
    <script src="<?php echo e(asset('assets/vendor/twitter-bootstrap-wizard/jquery.bootstrap.wizard.min.js')); ?>"></script>

    <!-- Wizard Form Demo js -->
    <script src="<?php echo e(asset('assets/js/pages/form-wizard.init.js')); ?>"></script>

    <!-- App js -->
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>

    
    <?php echo $__env->yieldContent('js'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\pshi\resources\views/layouts/app.blade.php ENDPATH**/ ?>