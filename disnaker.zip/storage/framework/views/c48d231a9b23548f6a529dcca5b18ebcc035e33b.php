

<?php $__env->startSection('title', 'Data Pengaduan'); ?>

<?php $__env->startSection('content'); ?>

<!-- Start Content-->
<div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dinas Ketenagakerjaan Kota Tanjung Balai</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('tickets.index')); ?>">Data Pengaduan</a></li>
                        <li class="breadcrumb-item active">Detail</li>
                    </ol>
                </div>
                <h4 class="page-title">Data Pengaduan</h4>
            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <?php if(session()->get('message')): ?>
                        <div class="alert alert-info">
                            <?php echo e(session()->get('message')); ?>    
                        </div>
                    <?php endif; ?>

                    <?php
                    $badge = [
                        'open' => 'bg-success',
                        'close' => 'bg-danger',
                    ];
                    ?>

                    <h2>Detail Pengaduan - <span class="badge <?php echo e($badge[strtolower($ticket->status)]); ?>"><?php echo e($ticket->status); ?></span></h2>
                    <div class="form-group row mb-3">
                        <label for="" class="col-3">Perusahaan / Pengguna</label>
                        <span class="col-9"><?php echo e($ticket->user->dataUmum?->nama_perusahaan ?? $ticket->user->name); ?></span>
                    </div>

                    <div class="form-group row mb-3">
                        <label for="" class="col-3">Subject</label>
                        <span class="col-9"><?php echo e($ticket->subject); ?></span>
                    </div>
                    
                    <div class="form-group row mb-3">
                        <label for="" class="col-3">Deskripsi</label>
                        <span class="col-9"><?php echo $ticket->description; ?></span>
                    </div>

                    <?php if(auth()->user()->role == 'Admin' && $ticket->status == 'OPEN'): ?>

                    <a href="<?php echo e(route('tickets.close', $ticket->id)); ?>" class="btn btn-danger">Mark as Close</a>
                    <?php endif; ?>
                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div> <!-- end row-->
    
    
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h2>Balasan</h2>
                    
                    <div class="timeline-2">
                        <?php $__currentLoopData = $ticket->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="time-item">
                            <div class="item-info ms-3 mb-3">
                                <div class="text-muted"><?php echo e($reply->created_at); ?></div>
                                <p><strong><a href="#" class="text-info"><?php echo e($reply->author->name); ?></a></strong></p>
                                
                                <?php echo $reply->description; ?>

                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php if($ticket->status == 'OPEN'): ?>
                    <form action="<?php echo e(route('tickets.reply', $ticket->id)); ?>" class="mt-3" method="POST">
                        <?php echo csrf_field(); ?>
                        <textarea name="description" id="" cols="30" rows="10" class="form-control mb-2" placeholder="Ketik balasan disini"></textarea>
                        <button class="btn btn-primary">Submit</button>
                    </form>
                    <?php endif; ?>
                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div> <!-- end row-->

    

</div>
<!-- container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pshi\resources\views/tickets/show.blade.php ENDPATH**/ ?>