<?php

    $data_umum = [
        'nama_perusahaan' => old('data_umum')['nama_perusahaan'] ?? ($dataUmum['nama_perusahaan'] ?? (session('data_input')['data_umum']['nama_perusahaan'] ?? '' )), 
        'alamat_perusahaan' => old('data_umum')['alamat_perusahaan'] ?? ($dataUmum['alamat_perusahaan'] ?? (session('data_input')['data_umum']['alamat_perusahaan'] ?? '' )),
        'no_telepon' => old('data_umum')['no_telepon'] ?? ($dataUmum['no_telepon'] ?? (session('data_input')['data_umum']['no_telepon'] ?? '' )),
        'email' => old('data_umum')['email'] ?? ($dataUmum['email'] ?? (session('data_input')['data_umum']['email'] ?? '' )),
        'jenis_usaha' => old('data_umum')['jenis_usaha'] ?? ($dataUmum['jenis_usaha'] ?? (session('data_input')['data_umum']['jenis_usaha'] ?? '' )),
        'nama_pemilik_perusahaan' => old('data_umum')['nama_pemilik_perusahaan'] ?? ($dataUmum['nama_pemilik_perusahaan'] ?? (session('data_input')['data_umum']['nama_pemilik_perusahaan'] ?? '' )),
        'alamat_pemilik_perusahaan' => old('data_umum')['alamat_pemilik_perusahaan'] ?? ($dataUmum['alamat_pemilik_perusahaan'] ?? (session('data_input')['data_umum']['alamat_pemilik_perusahaan'] ?? '' )),
        'pendirian_perusahaan' => old('data_umum')['pendirian_perusahaan'] ?? ($dataUmum['pendirian_perusahaan'] ?? (session('data_input')['data_umum']['pendirian_perusahaan'] ?? '' )),
        'no_akte_pendirian' => old('data_umum')['no_akte_pendirian'] ?? ($dataUmum['no_akte_pendirian'] ?? (session('data_input')['data_umum']['no_akte_pendirian'] ?? '' )),
        'status_perusahaan' => old('data_umum')['status_perusahaan'] ?? ($dataUmum['status_perusahaan'] ?? (session('data_input')['data_umum']['status_perusahaan'] ?? '' )),
        'status_kepemilikan' => old('data_umum')['status_kepemilikan'] ?? ($dataUmum['status_kepemilikan'] ?? (session('data_input')['data_umum']['status_kepemilikan'] ?? '' )),
    ];

?>

<div class="row">
    <div class="col-12">
        <div class="row mb-3">
            <label class="col-md-3 col-form-label" for="data_umum[nama_perusahaan]">Nama Perusahaan</label>
            <div class="col-md-9">
                <input type="text" id="data_umum[nama_perusahaan]" value="<?php echo e($data_umum['nama_perusahaan']); ?>" name="data_umum[nama_perusahaan]" class="form-control <?php $__errorArgs = ['data_umum.nama_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-md-3 col-form-label" for="data_umum[alamat_perusahaan]">Alamat Perusahaan</label>
            <div class="col-md-9">
                <input type="text" id="data_umum[alamat_perusahaan]" value="<?php echo e($data_umum['alamat_perusahaan']); ?>" name="data_umum[alamat_perusahaan]" class="form-control <?php $__errorArgs = ['data_umum.alamat_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-md-3 col-form-label" for="data_umum[no_telepon]">No Telepon</label>
            <div class="col-md-9">
                <input type="text" id="data_umum[no_telepon]" value="<?php echo e($data_umum['no_telepon']); ?>" name="data_umum[no_telepon]" class="form-control <?php $__errorArgs = ['data_umum.no_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-md-3 col-form-label" for="data_umum[email]">Email</label>
            <div class="col-md-9">
                <input type="email" id="data_umum[email]" value="<?php echo e($data_umum['email']); ?>" name="data_umum[email]" class="form-control <?php $__errorArgs = ['data_umum.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-md-3 col-form-label" for="data_umum[jenis_usaha]">Jenis Usaha</label>
            <div class="col-md-9">
                <input type="text" id="data_umum[jenis_usaha]" value="<?php echo e($data_umum['jenis_usaha']); ?>" name="data_umum[jenis_usaha]" class="form-control <?php $__errorArgs = ['data_umum.jenis_usaha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-md-3 col-form-label" for="data_umum[nama_pemilik_perusahaan]">Nama Pemilik Perusahaan</label>
            <div class="col-md-9">
                <input type="text" id="data_umum[nama_pemilik_perusahaan]" value="<?php echo e($data_umum['nama_pemilik_perusahaan']); ?>" name="data_umum[nama_pemilik_perusahaan]" class="form-control <?php $__errorArgs = ['data_umum.nama_pemilik_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-md-3 col-form-label" for="data_umum[alamat_pemilik_perusahaan]">Alamat Pemilik Perusahaan</label>
            <div class="col-md-9">
                <input type="text" id="data_umum[alamat_pemilik_perusahaan]" value="<?php echo e($data_umum['alamat_pemilik_perusahaan']); ?>" name="data_umum[alamat_pemilik_perusahaan]" class="form-control <?php $__errorArgs = ['data_umum.alamat_pemilik_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-md-3 col-form-label" for="data_umum[pendirian_perusahaan]">Pendirian Perusahaan</label>
            <div class="col-md-9">
                <input type="text" id="data_umum[pendirian_perusahaan]" value="<?php echo e($data_umum['pendirian_perusahaan']); ?>" name="data_umum[pendirian_perusahaan]" class="form-control <?php $__errorArgs = ['data_umum.pendirian_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-md-3 col-form-label" for="data_umum[no_akte_pendirian]">No Akte Pendirian</label>
            <div class="col-md-9">
                <input type="text" id="data_umum[no_akte_pendirian]" value="<?php echo e($data_umum['no_akte_pendirian']); ?>" name="data_umum[no_akte_pendirian]" class="form-control <?php $__errorArgs = ['data_umum.no_akte_pendirian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-md-3 col-form-label" for="data_umum[status_perusahaan]">Status Perusahaan</label>
            <div class="col-md-9">
                <input type="text" id="data_umum[status_perusahaan]" value="<?php echo e($data_umum['status_perusahaan']); ?>" name="data_umum[status_perusahaan]" class="form-control <?php $__errorArgs = ['data_umum.status_perusahaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-md-3 col-form-label" for="data_umum[status_kepemilikan]">Status Kepemilikan</label>
            <div class="col-md-9">
                <input type="text" id="data_umum[status_kepemilikan]" value="<?php echo e($data_umum['status_kepemilikan']); ?>" name="data_umum[status_kepemilikan]" class="form-control <?php $__errorArgs = ['data_umum.status_kepemilikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>
        </div>
    </div> <!-- end col -->
</div> <!-- end row --><?php /**PATH C:\laragon\www\pshi\resources\views/perusahaan/partials/data_umum.blade.php ENDPATH**/ ?>