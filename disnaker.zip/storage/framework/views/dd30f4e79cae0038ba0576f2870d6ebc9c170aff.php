

<?php $__env->startSection('title', 'Data Pengaduan'); ?>

<?php $__env->startSection('content'); ?>

<!-- Start Content-->
<div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dinas Ketenagakerjaan Kota Tanjung Balai</a></li>
                        <li class="breadcrumb-item active">Data Pengaduan</li>
                    </ol>
                </div>
                <h4 class="page-title">Data Pengaduan</h4>
            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <?php if(auth()->user()->role == 'Perusahaan'): ?>
                <div class="card-header">
                    <a href="<?php echo e(route('tickets.create')); ?>" class="btn btn-primary">
                        <i class="mdi mdi-plus"></i>
                        <span class="ml-2">Tambah Data</span>
                    </a>
                </div>
                <?php endif; ?>
                <div class="card-body">
                    <?php if(session()->get('message')): ?>
                        <div class="alert alert-info">
                            <?php echo e(session()->get('message')); ?>    
                        </div>
                    <?php endif; ?>

                    <table id="basic-datatable" class="table table-striped dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <?php if(auth()->user()->role != 'Perusahaan'): ?>
                                <th>Pengguna / Perusahaan</th>
                                <?php endif; ?>
                                <th>Subjek</th>
                                <th>Deskripsi</th>
                                <th>Prioritas</th>
                                <th>Status</th>
                                <th data-orderable="false">Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php if(auth()->user()->role != 'Perusahaan'): ?>
                                <td><?php echo e($data->user->dataUmum?->nama_perusahaan ?? $data->user->name); ?></td>
                                <?php endif; ?>
                                <td><?php echo e($data->subject); ?></td>
                                <td><?php echo e($data->description); ?></td>
                                <td><?php echo e($data->priority); ?></td>
                                <td><?php echo e($data->status); ?></td>
                                <td>
                                    <a href="<?php echo e(route('tickets.show', $data->id)); ?>" class="btn btn-warning"> 
                                        <i class="mdi mdi-eye"></i>
                                    </a>
                                    <?php if(auth()->user()->role == 'Perusahaan'): ?>
                                    <a href="javascript:void(0)" onclick="action(event, <?php echo e($data->id); ?>, 'delete')" class="btn btn-danger">
                                        <i class="mdi mdi-trash-can"></i>
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div> <!-- end row-->

</div>
<!-- container -->

<form action="<?php echo e(route('tickets.destroy', ':id')); ?>" method="POST" style="display: none;" id="form">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
    function action(event, id, type) {
        event.preventDefault()

        const confirmation = confirm('apakah anda yakin akan menghapus data ini ?')

        if(confirmation)
        {
            var form = document.getElementById('form')
            const action = form.action.replace(':id', id)
            form.setAttribute('action', action)
            form.submit()
        }
    }

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pshi\resources\views/tickets/index.blade.php ENDPATH**/ ?>