

<?php $__env->startSection('title', 'Data Perusahaan'); ?>

<?php $__env->startSection('content'); ?>
<!-- Start Content-->
<div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dinas Ketenagakerjaan Kota Tanjung Balai</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.accounts.index')); ?>">Data Akun Perusahaan</a></li>
                        <li class="breadcrumb-item active"><?php echo e(request()->routeIs('admin.accounts.create') ? 'Tambah' : 'Edit'); ?></li>
                    </ol>
                </div>
                <h4 class="page-title">Akun Perusahaan</h4>
            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                
                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            Gagal mengirimkan data!
                        </div>
                    <?php endif; ?>

                    <?php if(session()->get('status') == 'success'): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session()->get('message')); ?>

                        </div>
                    <?php elseif(session()->get('status') == 'failed'): ?>

                        <div class="alert alert-danger" role="alert">
                            <?php echo e(session()->get('message')); ?>

                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(request()->routeIs('admin.accounts.create') ? route('admin.accounts.store') : route('admin.accounts.update', $account->id)); ?>" method="post" id="form-main">
                        <?php echo csrf_field(); ?>

                        <?php if(request()->routeIs('admin.accounts.edit')): ?>
                        <?php echo method_field('PUT'); ?>
                        <?php endif; ?>

                        <div class="form-group mb-2">
                            <label for="" class="mb-1">Nama</label>
                            <input type="text" name="name" id="" class="form-control" value="<?php echo e(old('name', $account?->name)); ?>" placeholder="Nama Akun">
                        </div>
                        
                        <div class="form-group mb-2">
                            <label for="" class="mb-1">Email</label>
                            <input type="email" name="email" id="" class="form-control" value="<?php echo e(old('email', $account?->email)); ?>" placeholder="Email">
                        </div>
                        
                        <div class="form-group mb-2">
                            <label for="" class="mb-1">Password</label>
                            <input type="password" name="password" id="" class="form-control" value="" placeholder="Kata sandi">
                        </div>

                        <button class="btn btn-primary">Submit</button>
                        <a href="<?php echo e(route('admin.accounts.index')); ?>" class="btn btn-warning">Kembali</a>
                    </form>

                </div> <!-- end card-body -->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>

</div>
<!-- container -->

<form id="form" method="POST" style="display: none;">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="id">
    <input type="hidden" name="type">
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
    function action(event, id, type) {
        event.preventDefault()

        var form = document.getElementById('form')
        form['id'].value = id
        form['type'].value = type
        form.submit()
        
    }

    function submitForm(type) {
        var form = document.getElementById('form-main')
        form['type'].value = type
        form.submit()
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pshi\resources\views/admin/accounts/form.blade.php ENDPATH**/ ?>