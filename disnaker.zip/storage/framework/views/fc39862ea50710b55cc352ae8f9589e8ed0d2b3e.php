

<?php $__env->startSection('title', 'Tambah Data Kategori Fasilitas'); ?>

<?php $__env->startSection('content'); ?>

<!-- Start Content-->
<div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dinas Ketenagakerjaan Kota Tanjung Balai</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.kategori-fasilitas.index')); ?>">Data Kategori Fasilitas</a></li>
                        <li class="breadcrumb-item active">Tambah</li>
                    </ol>
                </div>
                <h4 class="page-title">Tambah Data Kategori Fasilitas</h4>
            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(route('admin.kategori-fasilitas.index')); ?>" class="btn btn-warning">
                        <i class="mdi mdi-arrow-left"></i>
                        <span class="ml-2">Kembali</span>
                    </a>
                </div>

                <div class="card-body">
                    <?php if(session()->get('message')): ?>
                        <div class="alert alert-info">
                            <?php echo e(session()->get('message')); ?>    
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('admin.kategori-fasilitas.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row mb-3">
                            <label class="col-md-3 col-form-label">Nama</label>
                            <div class="col-md-9 m-auto">
                                <input type="text" id="nama" name="nama" class="form-control" placeholder="Nama Kategori">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <button class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </form>
                    
                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div> <!-- end row-->

</div>
<!-- container -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pshi\resources\views/admin/ref/kategori-fasilitas/create.blade.php ENDPATH**/ ?>